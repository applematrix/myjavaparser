package com.hdz.myjavaparser;

public class MarkdownUtils {
    public final static int TITLE = 1;
    public final static int HEADER_1 = 2;
    public final static int HEADER_2 = 3;
    public final static int HEADER_3 = 4;
}
