package com.hdz.myjavaparser;

public class JavaClassDiff {


    public JavaClassDiff() {
    }
}
