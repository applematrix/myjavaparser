package com.hdz.myjavaparser;

public class JavaDiffUtils {
    public static final int CHANGE_TYPE_MISSED = 0;
    public static final int CHANGE_TYPE_NEW = 1;
    public static final int CHANGE_TYPE_INITIALIZER_CHANGED = 2;
    public static final int CHANGE_TYPE_VALUE_TYPE_CHANGED = 3;
    //public static final int CHANGE_TYPE_VALUE_TYPE_CHANGED = 3;
}
